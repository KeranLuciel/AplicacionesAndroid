package com.example.appdivisaslogin

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.appdivisaslogin.databinding.ActivitySecondActivityBinding

class SecondActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySecondActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySecondActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Cargar el CurrencyConverterFragment
        supportFragmentManager.beginTransaction()
            .replace(R.id.conversorContainer, CurrencyConverterFragment())
            .commit()

        // Obtener el valor del username
        val username = intent.getStringExtra("username")
        binding.tvWelcome.text = "Bienvenido $username! \uD83D\uDC31"

        // Configuramos el botón para cerrar sesión
        binding.btnLogout.setOnClickListener {
            finish() // Cambia a MainActivity si lo deseas
        }
    }
}