package com.example.appdivisaslogin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.appdivisaslogin.databinding.FragmentCurrencyConverterBinding

class CurrencyConverterFragment : Fragment() {

    private var _binding: FragmentCurrencyConverterBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCurrencyConverterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setupCurrencyConverter()
    }

    private fun setupCurrencyConverter() {
        val inputAmount = binding.editTextSoles
        val convertButton = binding.buttonConvertir
        val resultView = binding.textViewResultado
        val currencySpinner = binding.spinnerDivisas

        // Configurando el Spinner
        val currencies = arrayOf("Dólares", "Euros", "Pesos Mexicanos", "Yenes", "Wons")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, currencies)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        currencySpinner.adapter = adapter

        // Acción del botón de conversión
        convertButton.setOnClickListener {
            val amount = inputAmount.text.toString().toDoubleOrNull()
            val selectedCurrency = currencySpinner.selectedItem.toString()

            if (amount != null) {
                val result = when (selectedCurrency) {
                    "Dólares" -> convertToDollars(amount)
                    "Euros" -> convertToEuros(amount)
                    "Pesos Mexicanos" -> convertToPesosMx(amount)
                    "Yenes" -> convertToYenes(amount)
                    "Wons" -> convertToWons(amount)
                    else -> 0.0
                }
                resultView.text = "Resultado:\n$selectedCurrency: $result"
            } else {
                resultView.text = "Por favor, ingrese una cantidad válida"
            }
        }
    }

    // Funciones de conversión
    private fun convertToDollars(amount: Double): Double {
        val conversionRate = 0.27
        return amount * conversionRate
    }

    private fun convertToEuros(amount: Double): Double {
        val conversionRate = 0.24
        return amount * conversionRate
    }

    private fun convertToPesosMx(amount: Double): Double {
        val conversionRate = 5.28
        return amount * conversionRate
    }

    private fun convertToYenes(amount: Double): Double {
        val conversionRate = 38.79
        return amount * conversionRate
    }

    private fun convertToWons(amount: Double): Double {
        val conversionRate = 355.13
        return amount * conversionRate
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
